package задачи_25;

import java.util.Arrays;
import java.util.Comparator;
import java.util.Random;
import java.util.Scanner;

public class aa_25 {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        Random random = new Random();

//        // 1 ЗАДАЧА
//
////        Вывести на печать первый отрицательный элемент массива и его
////        порядковый номер, полагая, что в массиве есть хотя бы один отрицательный
////        элемент.
//
//        int[] arr = {1, 2, -3, 4, -5, 6,};
//
//        int arr1 = -1;
//
//        for (int i = 0; i < arr.length; i++) {
//            if (arr[i]<0){
//                arr1=i;
//                break;
//            }
//        }
//        if (arr1>=0){
//            System.out.println("Первый отрицательный элемент: " + arr[arr1] + ", порядковый номер: " + arr1);
//        }else {
//            System.out.println("В массиве нет отрицательных элементов.");
//        }
//
//        // 2 ЗАДАЧА
//
////        Вывести на печать номера элементов массива, удовлетворяющих
////        условию a[i]>10
//
//        int [] myArray = {1,2,33,66,8,90};
//
//        for (int i = 0; i < myArray.length; i++) {
//            if (myArray[i]>10){
//                System.out.println("Элемент с номером " + i + " удовлетворяет условию a[i] > 10: " + myArray[i]);
//            }
//        }
//
//        // 3 ЗАДАЧА
//
////        Даны   температуры   воздуха   за   неделю.   Определить   среднюю
////        температуру за неделю и сколько раз температура опускалась ниже 0º.
//
//        int [] myArray1 = new int[7];
//        myArray1[0]= 32;
//        myArray1[1]= 47;
//        myArray1[2]= -2;
//        myArray1[3]= 3;
//        myArray1[4]= -1;
//        myArray1[5]= 12;
//        myArray1[6]= -9;
//
//        int arr11=0;
//
//        for (int i = 0; i < myArray1.length; i++) {
//            if (myArray1[i]<=arr11){
//                arr11++;
//            }
//        }
//
//        int sumMyArray = Arrays.stream(myArray1).sum();
//        int average = sumMyArray / 7;
//
//        System.out.println("Темперетура воздуха в понидельник - "+myArray1[0]);
//        System.out.println("Темперетура воздуха в вторник - "+myArray1[1]);
//        System.out.println("Темперетура воздуха в среда - "+myArray1[2]);
//        System.out.println("Темперетура воздуха в четверг - "+myArray1[3]);
//        System.out.println("Темперетура воздуха в пятница - "+myArray1[4]);
//        System.out.println("Темперетура воздуха в субота - "+myArray1[5]);
//        System.out.println("Темперетура воздуха в васкрисения - "+myArray1[6]);
//        System.out.println("=====================================");
//        System.out.println("Средняя темперетура воздуха за неделю "+ average);
//        System.out.println(" Температура воздуха опускался ниже нуля:"+arr11);
//
//        // 4 ЗАДАЧА
//
//        //Даны   натуральные   числа     N,   a0,   a1,....,   a(N-1).   Определить
//        //количество членов последовательности имеющих четные порядковые номера
//        //и являющихся нечетными числами.
//
//        int[] array = {1,2,3,4,5,6,7,8,9};
//        int a = 0;
//        for (int i = 0; i < array.length; i++) {
//            if(array[i] % 2 == 1){
//                a++;
//            }
//        }
//        System.out.println("Кол-во: " + a);
//
//        // 5 ЗАДАЧА
//
////        Определить является ли данная последовательность убывающей (во
////        избежание лишних проверок использовать оператор break)
//
//        int[] sequence = {10, 8, 6, 4, 2};
//
//        boolean isDescending = true;
//
//        for (int i = 1; i < sequence.length; i++) {
//            if (sequence[i] >= sequence[i - 1]) {
//                isDescending = false;
//                break;
//            }
//        }
//
//        if (isDescending) {
//            System.out.println("Последовательность является убывающей.");
//        } else {
//            System.out.println("Последовательность не является убывающей.");
//        }
//
//        // 6 ЗАДАЧА
//
////        Дан массив чисел. Определить, сколько в нем пар одинаковых
////        соседних элементов
//
//        int[] arra = {1, 2, 2, 3, 3, 4, 4, 5};
//
//        int countPairs = 0;
//
//        for (int i = 1; i < arra.length; i++) {
//                if (arra[i-1]==arra[i]){
//                    countPairs++;
//                }
//            }
//        System.out.println("Количество пар одинаковых соседних элементов: " + countPairs);
//
//        // 7 ЗАДАЧА
//
//        //Дан   массив   чисел.   Найти   наибольший   элемент,   поставить   его
//        //первым.
//
//        int[] aa = {3, 4, 56, 7, 900, 84, 3, 4, 5,};
//        int b = aa[0];
//        int c = 0;
//        for (int i = 0; i < aa.length; i++) {
//            if (aa[i] > b) {
//                b = aa[i];
//                c = i;
//            }
//        }
//        int v = aa[0];
//        aa[0] = b;
//        aa[c] = v;
//        for (int d : aa) {
//            System.out.print(d + " ");
//        }
//
//
//        //8 ЗАДАЧА
//
//    //Задан двумерный массив, содержащий 3 строки и 4 столбца. Найти
//    //наибольший элемент, номер строки и столбца, в которых он расположен.
//
//    int[][] array = {
//            {1, 5, 9, 13},
//            {3, 7, 99, 15},
//            {2, 6, 10, 14}
//    };
//
//    int maxElement = array[0][0];
//    int row = 0;
//    int column = 0;
//
//        for (int i = 0; i < array.length; i++) {
//        for (int j = 0; j < array[i].length; j++) {
//        if (array[i][j] > maxElement) {
//        maxElement = array[i][j];
//        row = i;
//        column = j;
//
//        }
//
//        }
//
//        }
//
//        System.out.println("Наибольший элемент: " + maxElement);
//        System.out.println("Номер строки: " + row);
//        System.out.println("Номер столбца: " + column);
//
//        // 9 ЗАДАЧА
//
//        // Составить программу для вычисления средних арифметических
//        //значений положительных элементов каждого столбца двумерного массива,
//        //содержащего 6 столбцов и три строки. При условии, что в каждом столбце
//        //есть хотя бы один положительный элемент
//
//        int[][] array = {
//                {1, 2, -3, 4, -5, 6},
//                {-1, 2, 3, 4, 5, -6},
//                {6, -5, 4, -3, 2, 1}
//        };
//
//        int columns = array[0].length;
//        int rows = array.length;
//
//        for (int col = 0; col < columns; col++) {
//            int sum = 0;
//            int count = 0;
//
//            for (int row = 0; row < rows; row++) {
//                if (array[row][col] > 0) {
//                    sum += array[row][col];
//                    count++;
//                }
//            }
//
//            if (count > 0) {
//                double average1 = (double) sum / count;
//                System.out.println("Среднее значение столбца " + col + ": " + average1);
//            } else {
//                System.out.println("В столбце " + col + " нет положительных элементов");
//            }
//            }
//
//        //11 ЗАДАЧА
//
//        //Дана действительная квадратная матрица. Заменить нулями все
//        //элементы, расположенные на главной диагонали и  выше нее
//
//        // зделал с помощию чатжипити
//
//        int[][] matrix = {
//                {1, 2, 3, 4},
//                {5, 6, 7, 8},
//                {9, 10, 11, 12},
//                {13, 14, 15, 16}
//        };
//
//
//
//        for (int i = 0; i < matrix.length; i++) {
//            for (int j = 0; j < matrix.length; j++) {
//                if (i >= j) {
//                    matrix[i][j] = 0;
//                }
//            }
//        }
//
//        for (int i = 0; i < matrix.length; i++) {
//            for (int j = 0; j < matrix.length; j++) {
//                System.out.print(matrix[i][j] + " ");
//            }
//            System.out.println();
//        }

//
//
//        //14 ЗАДАЧА
//
//        //Дан двумерный массив, содержащий 5 строк и 2 столбца. Упорядочить
//        //массив по возрастанию элементов 2-го столбца
//
//        int[][] ll = {
//                {1, 4},
//                {8, 24},
//                {9, 875},
//                {6, 28},
//                {4, 7}
//        };
//
//        Arrays.sort(ll, Comparator.comparingInt(arr -> arr[1]));
//
//        for (int[] row : ll) {
//            System.out.println(Arrays.toString(row));
//        }
//
//
//        // 19 ЗАДАЧА
//
////        Напишите код, который создает 20 случайных чисел диапазона
////        1 - 99. Следует вывести в консоль только те числа которые делятся на 1-
////                ое рандомное число без остатка
//
//
//        int random1 = random.nextInt(1, 100);
//        System.out.println("Случайное число 1: " + random1);
//
//        for (int i = 2; i < 21; i++) {
//            int randomNumber = random.nextInt(1, 100);
//            System.out.println(i + ") " + randomNumber);
//            if (random1 % randomNumber == 0) {
//                System.out.println(randomNumber + " Это число делится на первое случайное число без остатка.");
//            } else {
//                System.out.println(" Это число делится но с останками.");
//            }
//        }
//
//          //22 ЗАДАЧА
//
//        //Найти второй наибольший элемент в массиве
//
//        int [] massive = {1,2,3,4,5,6,7,8,9};
//        int Max = massive[0];
//        for (int i = 0; i < massive.length-1; i++) {
//            if (massive[i] > Max){
//            Max = massive[i];            }
//        }
//        System.out.println("Наибольшой Элемент:"+Max);
//
//        // 24 ЗАДАЧА

        //Найти минимальное значение в массиве.
        //Напишите класс, который заполняет случайными двузначными
        //числами массив, размер которого вводится с клавиатуры.
        //После заполнения класс должен вывести на экран значения
        //массива следующим образом:
        //● в первой строке - первую половину массива
        //● во второй строке - вторую половину массива

//        System.out.println("ведите размер масива");
//        int [] ff = new int[scanner.nextInt()];
//        System.out.println(Arrays.toString(ss(ff)));
//        System.out.println("минимальное значение в масиве:");
//        System.out.println(Arrays.stream(ff).min());


        //25 ЗАДАЧА

        //напишите программу для добавления нового элемента в массив
//        System.out.println("Наш первоначальный масив");
//        int [] masiv = {1,4,65,6,2};
//        System.out.println(Arrays.toString(masiv));
//        System.out.println("Напишите цыфру которую хатите добавить:");
//        int dd = scanner.nextInt();
//
//        int []  newMassiv;
//
//        newMassiv = Arrays.copyOf(masiv,masiv.length+1);
//        newMassiv[newMassiv.length-1]=dd;
//        System.out.println(Arrays.toString(newMassiv));
//        masiv=Arrays.copyOf(newMassiv,newMassiv.length);
//        System.out.println("Наш массив после добавления");




    }
    public static int[] ss(int[] y){
        Random random = new Random();
        for (int i = 0; i < y.length; i++) {
            y[i]= random.nextInt(10,100);
        }
        return y;
    }
}
