import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class ArraySum {
    public static void main(String[] args) {



    }
}

//===========================================================
//        Scanner scanner = new Scanner(System.in);
//
//        System.out.println("Дабро пажаловать в колькулятор.");
//        System.out.println("Выберите дествие:");
//        System.out.println("1 - плюс.");
//        System.out.println("2 - минус.");
//        System.out.println("3 - умножение.");
//        System.out.println("4 - деление.");
//        System.out.println("5 - пратценты.");
//        System.out.println("6 - вйти из колькулятора.");
//
//
//        while (true) {
//            int qq = scanner.nextInt();
//            switch (qq) {
//                case 1:
//                    System.out.println("Ведите две цыфры которую хотите плюсовать:");
//                    System.out.print("Ваша 1 цыфра:");
//                    int w = scanner.nextInt();
//                    System.out.print("Ваша 2 цыфра:");
//                    int u = scanner.nextInt();
//                    int aa = w + u;
//                    System.out.println("Ваша сумма:" + aa);
//                    break;
//                case 2:
//                    System.out.println("Ведите две цыфры которую хотите минусовать:");
//                    System.out.print("Ваша 1 цыфра:");
//                    int ww = scanner.nextInt();
//                    System.out.print("Ваша 2 цыфра:");
//                    int uu = scanner.nextInt();
//                    int aaa = ww - uu;
//                    System.out.println("Ваша сумма:" + aaa);
//                    break;
//                case 3:
//                    System.out.println("Ведите две цыфры которую хотите умножить:");
//                    System.out.print("Ваша 1 цыфра:");
//                    int w1 = scanner.nextInt();
//                    System.out.print("Ваша 2 цыфра:");
//                    int u1 = scanner.nextInt();
//                    int aa1 = w1 * u1;
//                    System.out.println("Ваша сумма:" + aa1);
//                    break;
//                case 4:
//                    System.out.println("Ведите две цыфры которую хотите делить:");
//                    System.out.print("Ваша 1 цыфра:");
//                    int q = scanner.nextInt();
//                    System.out.print("Ваша 2 цыфра:");
//                    int r = scanner.nextInt();
//                    int tt = q / r;
//                    System.out.println("Ваша сумма:" + tt);
//                    break;
//                case 5:
//                    System.out.println("Ведите две цыфры которую хотите продценты:");
//                    System.out.print("Ваша 1 цыфра:");
//                    int l = scanner.nextInt();
//                    System.out.print("Ваша 2 цыфра:");
//                    int k = scanner.nextInt();
//                    int c = l % k;
//                    System.out.println("Ваша сумма:" + c);
//                    break;
//                case 6:
//                    System.out.println("Подаждите секунду!");
//                    System.out.println("Мы рады что вы пользуйтес с нашей системай ❤❤❤");
//                    return;
//            }
//        aa();
//        }
//
//    }
//    static void aa(){
//        System.out.println("Выберите дествие:");
//        System.out.println("1 - плюс.");
//        System.out.println("2 - минус.");
//        System.out.println("3 - умножение.");
//        System.out.println("4 - деление.");
//        System.out.println("5 - пратценты.");
//        System.out.println("6 - выти из колькулятора.");

//============================================================
//        Scanner scanner = new Scanner(System.in);
//
//        String[] Myarraylist = {" Залкр ", " Нуртилек "};
//        System.out.println("""
//                1.добавить новое имя.
//                2.удаоить имя по индексу.
//                3.получить имя по индексу.
//                4.получить индекс по имени.
//                5.вывести все имена.
//                """);
//
//        int t;
//
//        int w = scanner.nextInt();
//        switch (w){
//            case 1:
//
//                break;
//            case 2:
//
//                break;
//            case 3:
//                System.out.println("ведите индекс:");
//                t= scanner.nextInt();
//                String_get(t,Myarraylist);
//                break;
//            case 4:
//
//                break;
//            case 5:
//                String_toArray(Myarraylist);
//                break;
//
//
//        }
//
//    }
//
//
//
//    public static void String_get(int y,String [] w){
//        if (y >= 0 && y < w.length) {
//            String name = w[y];
//            System.out.println("Имя по индексу " + y + ": " + name);
//        } else {
//            System.out.println("Индекс выходит за пределы массива.");
//        }
//        }
//
//
//    public static void String_toArray(String [] s){
//        System.out.println(Arrays.toString(s));
//    }
//
//}
        ////////////////////////////////////////////////////////////////////////////
////        int[] array1 = {1, 2, 3};
////        int[] array2 = {1, 2, 3};
////
////        aa(array1);
////        System.out.println("==========");
////        int [] c = dd(array2);
////        System.out.println(Arrays.toString(c));
////
////        ///////////////////////////////////////////////////////
////
////        int[] sumArray = addArrays(array1, array2);
////
////        if (sumArray != null) {
////            printArray(sumArray);
////        } else {
////            System.out.println("Массивы имеют разную длину.");
////        }
//
//        /////////////////////////////////////////////////////
//
//        String [] arr = {"мандарин","киткат","праграмист"};
//
//        ss(arr);
//    }
////=====================================================================
//    public static int[] addArrays(int[] arr1, int[] arr2) {
//        if (arr1.length != arr2.length) {
//            return null;
//        }
//
//        int[] sumArray = new int[arr1.length];
//        for (int i = 0; i < arr1.length; i++) {
//            sumArray[i] = arr1[i] + arr2[i];
//        }
//
//        return sumArray;
//    }
//
//

//    /////////////////////////////////////////////
//    public static void aa(int [] ff) {
//        System.out.println(Arrays.toString(ff));
//    }
//
//    public static int[] dd(int [] gg) {
//
//        return gg;
//    }
//    /////////////////////////////////////////////////////
//    public static void ss (String [] pp){
//        for (int i = 0; i < pp.length; i++) {
//            System.out.println("маи слава\n"+Arrays.toString(pp));
//            System.out.println(pp[i].length());
//
//        }

//        int a = 10;
//        int b = 10;
//        int c = a + b / 2;
//        System.out.println(a);
//        System.out.println(b);
//        System.out.println(c);
//
//        int length = 10;
//        int width = 5;
//        int s = length * width;
//        System.out.println("Длина прямоугольника:" + length);
//        System.out.println("Ширина прямоугольника:" + width);
//        System.out.println("Площадь прямоугольника:" + s);
//
//        int num1 = 5;
//        int num2 = 10;
//
//        int temp;
//
//        System.out.println("Исходные значения:");
//        System.out.println("num1 = " + num1);
//        System.out.println("num2 = " + num2);
//
//        temp = num1;
//        num1 = num2;
//        num2 = temp;
//
//        System.out.println("После обмена:");
//        System.out.println("num1 = " + num1);
//        System.out.println("num2 = " + num2);
//
//        Scanner scanner = new Scanner(System.in);
//        System.out.print("Введите 3-значное число: ");
//        int number = scanner.nextInt();
//
//        int digit1 = number / 100;
//        int digit2 = (number / 10) % 10;
//        int digit3 = number % 10;
//
//        System.out.println(digit1 + "," + digit2 + "," + digit3);
//
//        System.out.print("Введите целое число от 0 до 1000: ");
//        int number = scanner.nextInt();
//
//        int sum = 0;
//        int originalNumber = number;
//
//        while (number > 0) {
//            int digit = number % 10;
//            sum += digit;
//            number /= 10;
//        }
//
//        System.out.println("Сумма всех цифр в числе " + originalNumber + " равна " + sum + ".");
//
//        int a = scanner.nextInt();
//        if (a == 18 && a < 18) {
//            System.out.println("Совершеннолетний");
//        } else {
//            System.out.println("Не совершеннолетний");
//        }
//
//
//        for (int i = 0; i < 4; i++) {
//            System.out.println("************");
//        }
//
//        int rows = 6;
//
//        for (int i = 1; i <= rows; i++) {
//
//            for (int j = 1; j <= i; j++) {
//                System.out.print("*");
//            }
//            System.out.println();
//        }
//
//        int rows = 6;
//
//        for (int i = 1; i <= rows; i++) {
//
//            for (int j = 1; j <= rows - i; j++) {
//                System.out.print("  ");
//            }
//
//            for (int k = 1; k <= i; k++) {
//                System.out.print("* ");
//            }
//
//            System.out.println();
//        }
//
//        int rows = 6;
//
//        for (int i = 0; i < rows; i++) {
//
//            for (int j = 0; j < rows - i - 1; j++) {
//                System.out.print("  ");
//            }
//
//            for (int k = 0; k < 2 * i + 1; k++) {
//                System.out.print("* ");
//            }
//
//            System.out.println();
//        }
//
//        int rows = 5;
//
//        for (int i = 1; i <= rows; i++) {
//
//            for (int j = 1; j <= rows - i; j++) {
//                System.out.print(" ");
//            }
//
//            for (int k = 1; k <= 2 * i - 1; k++) {
//                System.out.print(i);
//            }
//
//        }
