package Баккавская_система;

import java.util.Random;
import java.util.Scanner;

public class Bank {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        Random random = new Random();

//        System.out.println("\n" + " Добро пожаловать в банковскому систему Бакай банк! ");
//        System.out.println(" У вас есть акаунт ? \n" +
//                " Если нету то вы должны  пройти регистрацию. ");
//        System.out.println(" 1 - Есть.\n " +
//                "2 - Нету. ");
//        int d = scanner.nextInt();
//        if (d == 2) {
//            System.out.println(" Ведите ФИО: ");
//            String f = scanner.next();
//
//            System.out.println(" Ведите Инн: ");
//            while (true) {
//                String dd = scanner.next();
//                if (dd.length() != 15) {
//                    System.out.println(" Инн должен быть не больше и не меньше 15 цыфр! ");
//                } else {
//                    break;
//                }
//            }
////////////////////////////////////////////////////////////////
//            int ff;
//            do {
//                System.out.println(" Ведите возрасть: ");
//                ff = scanner.nextInt();
//            } while (ff > 127 || ff < 1);
////////////////////////////////////////////////////////////////
//        System.out.println(" Ведите номер телефона: ");
//        while (true) {
//            String dd = scanner.next();
//            if (dd.contains("+996") && dd.length() == 13) {
//                break;
//            } else {
//                System.out.println(" Мы примаем толька кыргыский номер! ");
//            }
//        }
////////////////////////////////////////////////////////////////
//        System.out.println(" Ведите пачту: ");
//        String d;
//       while (true) {
//             d= scanner.next();
//            if (d.contains("@gmail.com") || d.contains("@mail.ru") || d.contains("@aol.ca") || d.contains("@peaksoft.us")) {
//                break;
//            } else {
//                System.out.println(" Ваша почта не коректно! ");
//            }
//        }
//////////////////////////////////////////////////////////////////////////
//        System.out.println(" Ведите пароль: ");
//        String wd = scanner.next();
//         while (true) {
//            if (wd.length() >8) {
//                break;
//            } else {
//                System.out.println(" Ваш пароль не должен быть короче 8 символов \n " +
//                        " и должен содержать специальные символы \n " +
//                        " (например, !, @, #, $).");
//            }
//        }
/////////////////////////////////////////////////////////////////////////////////
//        System.out.println(" Что бы зайти в акаунт потарите свой почту и пароль. ");
//        System.out.println(" Ведите почту: ");
//        while (true){
//             String l = scanner.next();
//            if (l.contains(d)){
//                break;
//            }else {
//                System.out.println(" Ваша почта не савпадають. ");
//                System.out.println(" Повторите снова. ");
//            }
//        }
//////////////////////////////////////////////////////////////////////////////////
//        System.out.println(" Ведите пароль: ");
//        while (true){
//            String se = scanner.next();
//            if (se.contains(wd)){
//                break;
//            }else {
//                System.out.println(" Ваша пароль не савпадають. ");
//                System.out.println(" Повторите снова. ");
//            }
//        }
////////////////////////////////////////////////////////////////////////////////////
        System.out.println(" Ваш номер карты ");
        System.out.println("""
                |====================|
                |  1234567890123456  |
                |====================|
                """);
        System.out.println(" Вам доступны следушие функции. ");
        menu();
        int  ab;
        int rt= 100000000;
        while (true){
            ab= scanner.nextInt();
            switch (ab){
                case 1:
                    System.out.println(" ваш баланс: ");
                    System.out.println(" --> "+rt+" <-- \n");

                    break;
                case 2:
                    System.out.println(" Укажите сумму каторую хотите cнять: ");
                    int pp = scanner.nextInt();
                    System.out.println(" Ваша сумма успештно снята! \n");
                    int io = rt-pp;
                    System.out.println(" Ваша сумма после снятия: "+io+"\n");
                    break;
                case 3:
                    System.out.println(" Укажите сумму каторую хотите перевести: ");
                    int yp = scanner.nextInt();
                    System.out.println(" Ваша сумма успештно переведино! \n");
                   int uyu = rt-yp;
                    System.out.println(" Ваша сумма после поревода "+uyu+"\n");
                    break;
                case 4:
                    System.out.println(" Укажите сумму для пополнения баланса: ");
                    int wq = scanner.nextInt();
                    System.out.println(" Ваша пополнения баланса ушпешно завершён! \n");
                    int re = rt+wq;
                    System.out.println(" Ваша сумма после пополнение "+re+"\n");
                    break;
            }
            switch (ab){
                case 8:
                    return;
                }
            menu();

        }

        }


    public static void menu(){
        System.out.println("""
                1. Проверить баланс\s
                2. Снять деньги\s
                3. Перевести деньги\s
                4. Пополнить баланс\s
                5. Взять кредит \s
                6. Конвертация\s
                7. Получить инфо об аккаунте\s
                8. Выйти\s
                                
                """);
    }
}
