package расписание;

import java.util.Random;

public class расписание {
    public static void main(String[] args) {

        Random random = new Random();

        System.out.println("Начала дня");
        int y = random.nextInt(1,3);
        if (y==1){
            System.out.println("");
        }

    }
}
