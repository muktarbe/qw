package ООП;

public class People {
    String name;
    String fill_name;
    int age;

    @Override
    public String toString() {
        return "Peplle{" +
                "name='" + name + '\'' +
                ", fill name='" + fill_name + '\'' +
                ", age=" + age +
                '}';
    }
}
