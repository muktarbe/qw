package ООП;

public class Phone {
    String brend;
    String model;
    int price;
    int memory;

    public void call(){
        System.out.println(brend+" "+model+" "+" phone is calling ");
    }
    public String listen (){
        return " Listening "+brend+" "+model;
    }


    @Override
    public String toString() {
        return "Phone \n" +
                "brend = " + brend +
                ", madel = " + model +
                ", price = " + price +
                ", memory = " + memory+"." ;
    }
}
