package ООП;

import java.util.Scanner;

public class ООП {
    public static void main(String[] args) {

        Peplle peplle1 = new Peplle();
        peplle1.name= " Bekzat";
        peplle1.fill_name="Mamatkarimov";
        peplle1.age=18;

        Peplle peplle2 = new Peplle();
        peplle2.name= " kanybek";
        peplle2.fill_name="Isaev";
        peplle2.age=16;

        Peplle peplle3 = new Peplle();
        peplle3.name= " Muktarbek";
        peplle3.fill_name="Elebesov";
        peplle3.age=17;

        System.out.println(peplle1);
        System.out.println(peplle2);
        System.out.println(peplle3);

//        Phone phone1 = new Phone();
//        phone1.brend = "Iphone";
//        phone1.model = "13 pro";
//        phone1.price = 15000;
//        phone1.memory = 5555;
//
//
//        Phone phone2 = new Phone();
//        phone2.brend = "Samsung";
//        phone2.model = "A51";
//        phone2.price = 13000;
//        phone2.memory = 312;
//
//
//        Phone phone3 = new Phone();
//        phone3.brend = "Redmi";
//        phone3.model = "7";
//        phone3.price = 35000;
//        phone3.memory = 234;
//
//        phone1.call();
//        phone2.call();
//        phone3.call();
//
//        System.out.println("\n");
//
//        System.out.println(phone3.listen());
//
//        Phone [] phones = new Phone[]{phone1,phone2,phone3};
//
//        arraySort(phones,"Redmi");


    }
    public static void arraySort(Phone []phones,String bred){
        for (Phone phone:phones) {
            if (phone.brend.contains(bred)){
                System.out.println(phone);
            }
        }
    }
}
